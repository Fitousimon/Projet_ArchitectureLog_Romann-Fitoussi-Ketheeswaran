package main;

/**
 * Classe Main, afin de tester les fonctions impl�ment�es
 * 
 *
 */
public class Main {
	public static void main(String[] args) {

	}
}
