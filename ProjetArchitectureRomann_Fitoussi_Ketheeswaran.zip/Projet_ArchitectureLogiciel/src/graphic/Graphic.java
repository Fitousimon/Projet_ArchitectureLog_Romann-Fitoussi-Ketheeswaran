package graphic;
/**
 * 
 * 
 * Interface graphique qui va implementer des classes telles CompositeGraphic
 * etc ...
 *
 */

public interface Graphic {

	void print();

}
