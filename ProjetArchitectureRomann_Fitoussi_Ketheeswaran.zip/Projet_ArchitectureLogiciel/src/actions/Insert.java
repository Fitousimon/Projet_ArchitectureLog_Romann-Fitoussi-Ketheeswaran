package actions;

public class Insert {

}
