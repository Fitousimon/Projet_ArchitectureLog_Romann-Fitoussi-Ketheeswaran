package actions;

public class Label {

}
